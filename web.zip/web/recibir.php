<?php

echo '<h1>'.$_GET['nombre'].'</h1>';

echo '<h1>'.$_GET['apellidos'].'</h1>';

var_dump($_GET);

echo '</br>';

$dia = 7;

switch ($dia){

	case 1:

	echo "LUNES";
	break;

	case 2:
	echo "MARTES";
	break;

        case 3:
        echo "MIERCOLES";
        break;

        case 4:
        echo "JUEVES";
        break;

        case 5:
        echo "VIERNES";
        break;

	default:
	    echo " ES FIN DE SEMANA";
}


//GOTO
echo"</br>";
goto marca;
echo "<h3>Instruccion 1</h3>";

echo "<h3>Instruccion 1</h3>";

echo "<h3>Instruccion 1</h3>";

echo "<h3>Instruccion 1</h3>";

marca:

echo "me salte los echos";


// bucle while

// Estructura de control que itera o repite

echo "</br>";

$numero = 0;

while($numero <= 100){
      echo $numero;
//    echo "<p>$numero</p>";

     if($numero != 100){
      echo ", ";

     }
    $numero++;
}

echo "<hr/>";

if(isset($_GET['numero'])){
	$numero = $_GET['numero'];
}else{
	$numero =1;
}

var_dump($numero);

echo "<hr/>";

$numero = 33;
echo "<h1>Tabla de Multiplicar del Número $numero</h1>";

$contador = 1;

while($contador <= 10){
	echo "$numero x $contador = ".($numero*$contador)."<br/>";
	$contador++;

}

echo "<hr/>";

// $i = contador

$resultado = 0;
for($i =0; $i <= 100; $i++){
    $resultado = $resultado + $i;
    //echo "<p>$resultado</p>";
}

echo "<h1> El resultado es: $resultado </h1>";








?>
