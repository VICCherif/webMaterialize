<?php

$v1 = "Hola mundo desde una variable";

echo '<h1>'.$v1.'</h1>';

/*
Tipos de datos
Entero (int / interger) = 99
coma lotante / decimales (float / double)
*/

define('nombre','victo cherif');
define('Web','cpsesor.cl');


echo '<h1>'.nombre.'</h1>';
echo '<h1>'.Web.'</h1>';

echo '<h1>';
echo $_SERVER['SERVER_NAME'];
echo '</h1>';

?>
