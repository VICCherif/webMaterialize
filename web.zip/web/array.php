<?php


//Arrays


/*
$Pelicula = ['p1' => 'Star Wars EP I',
	     'p2' =>'Avengers',
	      'p3' =>'Batman El caballero de la noche'];
*/

echo"<h2>Listado de peliculas</h2>";

$Pelicula = ['Star Wars EP I','Avengers','Batman El caballero de la noche'];

echo "<ul>";

//for($i = 0; $i <= count($Pelicula); $i++){
	//echo "<li>".$Pelicula[0]."</li>";

echo "<table>";
echo "<thead>";
    echo "<tr>";
        echo"<th>PeliCulas</th>";
    echo"</tr>";
       echo "</thead>";

   echo"<tbody>";
      echo"<tr>";
            echo"<td>".$Pelicula[0]."</td>";
      echo"</tr>";

      echo"<tr>";
            echo"<td>".$Pelicula[1]."</td>";
      echo"</tr>";

      echo"<tr>";
            echo"<td>".$Pelicula[2]."</td>";
      echo"</tr>";

      echo"</tbody>";
echo "</table>";


//}

echo "</ul>";

//var_dump($Pelicula);




?>
