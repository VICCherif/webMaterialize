
<!DOCTYPE html>
<html lang="es">
<head>

  <meta name="description" content="Tutorial Web Gratis">
  <meta name="keywords" content="HTML, CSS, JavaScript, Materialize,PHP">
  <meta name="author" content="Victor Cherif">
  <meta name="Pagina Web" content="https://cpsesor.cl/">

<title>Materialize Web VC</title>

<script src="js/materialize.min.js" type="text/javascript"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="css/materialize.min.css" rel="stylesheet">

</head>
<body>

<?php
$array = array(
    "Nombre" => "Victor",
    "Apellido" => "Cherif",
    "Pais" => "Chile",
    "Ciudad" => "Santiago",
    "Comuna" => "La Florida",
    "Ocupacion" => "Estudiante",
    "Pasatiempo" => "Tocar guitarra",
    "Carrera" => "Ingeneria En informatica",
    "Edad" => "28"
 );

?>
<nav>
    <div class="nav-wrapper teal lighten-2">
      <a href="#" class="brand-logo center"> <i>Titutlo de mi web</i></a>
      <ul id="nav-mobile" class="left hide-on-med-and-down">
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
      </ul>
    </div>
  </nav>

<center>

<h2>Bienvenidos<h2>

<p>cita</p>

<blockquote>

Esto es un Ejemplo para referencia de una cita de texto

</blockquote>


        <h2>Listado  De Lenguajes</h2>
<ul>
        <li>HTML5</li>
        <li>PHP</li>
        <li>MySQL</li>
        <li>Python3</li>
        <li>CSS</li>
</ul>

<img src="img/103988.jpg" alt="Imagen del universo" title="Universo" width="455px">

</center>

</br>

<center>

<table border="1" class="centered">
        <thead>
          <tr>
              <th>Nombre</th>
              <th>Apellido</th>
              <th>Pais</th>
              <th>Ciudad</th>
              <th>Comuna</th>
              <th>Ocupacion</th>
              <th>Pasatiempo</th>
              <th>Carrera</th>
              <th>Edad</th>
          </tr>
        </tr>

        <tbody>
          <tr>
            <td><?php echo $array["Nombre"] ?></td>
            <td><?php echo $array["Apellido"] ?></td>
            <td><?php echo $array["Pais"] ?></td>
            <td><?php echo $array["Ciudad"] ?></td>
            <td><?php echo $array["Comuna"] ?></td>
            <td><?php echo $array["Ocupacion"] ?></td>
            <td><?php echo $array["Pasatiempo"] ?></td>
            <td><?php echo $array["Carrera"] ?></td>
            <td><?php echo $array["Edad"] ?></td>
          </tr>
        </tbody>

      </table>
	</br>
<div class="container2">
    <div class="row">

         <h6 class="left-align">
            Formulario test
        </h6>

        <form>
        <div class="row">
                <div class="input-field col s3">
                        <label for="Nombre">Nombre</label>
                        <textarea name="Nombre"></textarea>
                </div>



                <div class="input-field col s3">
                        <label for="descripcion">Descripcion</label>
                        <textarea name="descripcion"></textarea>
                </div>
        </div>
        </form>
	


      </div>
</div>

    </br>
    
    <center>
        <p>&copy;VCherif</p>
    </center>		
</body>

</html>
